# Minecraft 3D Survival - Architecture (Phase 1)

## Engine / Xogot
- Xogot on the App Store runs Godot 4.7. A Godot 4.8 beta is available only via the separate XogotBeta TestFlight app.
- Recommendation: open this project in the App Store Xogot (Godot 4.7). Code uses only APIs available since Godot 4.3 (e.g. Image.create_empty), so it should also open in 4.8 beta.
- Renderer: Mobile (Vulkan/Metal path). Compatibility renderer is the fallback if a device misbehaves.
- config/features is "4.3"; Xogot may offer to upgrade the project metadata on open: accept.

## Core design decisions
1. Data-oriented voxels: a chunk is one PackedByteArray (16x64x16 = 16 KB). No node per block.
2. One MeshInstance3D per chunk, hidden faces culled, one material/atlas -> one draw call per chunk.
3. Chunk generation and meshing run on WorkerThreadPool; the main thread only creates meshes (max 2 per frame).
4. Data is generated one ring beyond the meshed radius so chunk borders cull correctly.
5. Custom voxel AABB collision for the player (reads block data directly; no physics bodies, no trimesh rebuilds).
6. Block definitions are const tables, safe to read from threads.
7. Face brightness is baked into vertex colours with an unshaded material (cheapest option on mobile).
8. Scene is built in code from a tiny main.tscn, so there is no hand-edited scene-file risk.

## Folder structure
res://
  project.godot
  scenes/main.tscn
  scripts/main.gd
  scripts/autoload/  event_bus.gd, game_settings.gd
  scripts/core/      game_constants.gd
  scripts/voxel/     block_atlas.gd, block_registry.gd, chunk_data.gd, chunk_mesher.gd, terrain_generator.gd, voxel_world.gd
  scripts/player/    player.gd
  scripts/ui/        touch_controls.gd, debug_hud.gd
  docs/ARCHITECTURE.md

## Dependency order (no cycles)
GameConstants <- BlockAtlas <- BlockRegistry <- ChunkData <- ChunkMesher / TerrainGenerator <- VoxelWorld <- Player / UI <- main.gd
Autoloads: EventBus (signals), GameSettings (tunables + runtime input actions).

## Roadmap
- Phase 2: block interaction: voxel raycast, break/place, chunk remesh, hotbar UI, touch buttons.
- Phase 3: world generation: biomes, trees, caves, water, ores.
- Phase 4: inventory, items, crafting.
- Phase 5: survival: health, hunger, day/night, light levels, mobs.
- Phase 6: save/load (chunk delta files), settings menu.
- Phase 7: performance pass (greedy meshing, LOD/fog, safe area), audio, iOS export.

## Risks and mitigations
- GDScript meshing is slow -> run on worker threads, cap main-thread work per frame, small chunk height.
- Class cache not built on first open (class_name errors) -> Project > Reload Current Project.
- Memory growth -> 16 KB per chunk, unload beyond render_distance + 2.
- Pop-in at view edge -> fog/fade planned for Phase 7; keep render_distance at 3 on phones.
- Touch conflicts between joystick/look/jump -> separate touch indices per control.
- 120 Hz displays vs 60 Hz physics -> max_fps capped at 60; interpolation later.
- Thread-safety -> workers only touch const data, their own arrays and a mutex-guarded queue.
