class_name GameConstants
extends RefCounted
## Project-wide constants. One block = 1.0 world unit = 1 metre.

const BLOCK_SIZE := 1.0
const CHUNK_SIZE := 16     # blocks per chunk side (X and Z)
const CHUNK_HEIGHT := 64   # blocks per chunk column (raise in later phases if needed)
