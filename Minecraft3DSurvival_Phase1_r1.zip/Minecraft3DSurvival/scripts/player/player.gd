class_name Player
extends Node3D
## First-person player with custom voxel AABB collision (no physics bodies needed).
## `position` is the centre of the player's feet. Call setup() AFTER add_child().

const HALF_WIDTH := 0.3
const HEIGHT := 1.8
const EYE_HEIGHT := 1.62
const WALK_SPEED := 4.5
const GRAVITY := 28.0
const JUMP_SPEED := 8.5
const TERMINAL_SPEED := 50.0
const EPS := 0.001
const MAX_STEP := 0.5   # max distance moved per collision test (must stay < 1 block)

var velocity := Vector3.ZERO
var on_floor := false
var yaw := 0.0
var pitch := 0.0

var _world: VoxelWorld
var _touch: TouchControls
var _camera: Camera3D
var _pos := Vector3.ZERO


func _ready() -> void:
	_camera = Camera3D.new()
	_camera.position = Vector3(0, EYE_HEIGHT, 0)
	_camera.fov = GameSettings.fov
	_camera.near = 0.05
	_camera.far = 400.0
	add_child(_camera)
	_camera.current = true


func setup(world: VoxelWorld, touch: TouchControls, spawn: Vector3) -> void:
	_world = world
	_touch = touch
	_pos = spawn
	position = spawn
	EventBus.player_spawned.emit(spawn)


func _process(_delta: float) -> void:
	if _touch == null:
		return
	var look := _touch.consume_look()
	if look != Vector2.ZERO:
		yaw -= look.x * GameSettings.look_sensitivity
		pitch = clampf(pitch - look.y * GameSettings.look_sensitivity, -1.55, 1.55)
		rotation.y = yaw
		_camera.rotation.x = pitch


func _physics_process(delta: float) -> void:
	if _world == null or not _world.has_data_at(_pos):
		return  # wait for the terrain under us to exist
	delta = minf(delta, 1.0 / 30.0)

	var input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	input += _touch.move_vector
	if input.length() > 1.0:
		input = input.normalized()
	var forward := -transform.basis.z
	var right := transform.basis.x
	var wish := right * input.x + forward * (-input.y)

	velocity.x = wish.x * WALK_SPEED
	velocity.z = wish.z * WALK_SPEED
	velocity.y = maxf(velocity.y - GRAVITY * delta, -TERMINAL_SPEED)

	var jump_wanted := _touch.jump_down or Input.is_action_pressed("jump")
	if jump_wanted and on_floor:
		velocity.y = JUMP_SPEED
		on_floor = false

	_move_axis(0, velocity.x * delta)
	_move_axis(2, velocity.z * delta)
	var vy := velocity.y
	var blocked_y := _move_axis(1, vy * delta)
	if blocked_y:
		on_floor = vy <= 0.0
		velocity.y = 0.0
	else:
		on_floor = false
	position = _pos


## Moves along one axis (0=x, 1=y, 2=z) in sub-steps of at most MAX_STEP so a long step
## (frame hitch at terminal fall speed) can never end deeper than one block inside terrain.
## Returns true if movement was blocked.
func _move_axis(axis: int, amount: float) -> bool:
	if amount == 0.0:
		return false
	var steps := maxi(1, ceili(absf(amount) / MAX_STEP))
	var step_amount := amount / steps
	for _i in range(steps):
		if _move_axis_step(axis, step_amount):
			return true
	return false


## One collision-tested move. On collision, snaps flush against the block.
func _move_axis_step(axis: int, amount: float) -> bool:
	_pos[axis] += amount
	if not _collides():
		return false
	match axis:
		0:
			if amount > 0.0:
				_pos.x = floorf(_pos.x + HALF_WIDTH) - HALF_WIDTH - EPS
			else:
				_pos.x = floorf(_pos.x - HALF_WIDTH) + 1.0 + HALF_WIDTH + EPS
		1:
			if amount > 0.0:
				_pos.y = floorf(_pos.y + HEIGHT) - HEIGHT - EPS
			else:
				_pos.y = floorf(_pos.y) + 1.0
		2:
			if amount > 0.0:
				_pos.z = floorf(_pos.z + HALF_WIDTH) - HALF_WIDTH - EPS
			else:
				_pos.z = floorf(_pos.z - HALF_WIDTH) + 1.0 + HALF_WIDTH + EPS
	return true


func _collides() -> bool:
	var x0 := floori(_pos.x - HALF_WIDTH)
	var x1 := floori(_pos.x + HALF_WIDTH)
	var y0 := floori(_pos.y)
	var y1 := floori(_pos.y + HEIGHT)
	var z0 := floori(_pos.z - HALF_WIDTH)
	var z1 := floori(_pos.z + HALF_WIDTH)
	for y in range(y0, y1 + 1):
		for z in range(z0, z1 + 1):
			for x in range(x0, x1 + 1):
				if _world.is_solid(x, y, z):
					return true
	return false
