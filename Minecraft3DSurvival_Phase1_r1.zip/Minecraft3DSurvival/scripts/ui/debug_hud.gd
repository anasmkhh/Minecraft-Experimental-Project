class_name DebugHUD
extends Label
## Performance + world statistics overlay (updates 4x per second).

var _world: VoxelWorld
var _player: Player
var _touch: TouchControls
var _accum := 0.0


func _ready() -> void:
	position = Vector2(70, 12)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_theme_font_size_override("font_size", 20)
	add_theme_color_override("font_outline_color", Color.BLACK)
	add_theme_constant_override("outline_size", 6)


func setup(world: VoxelWorld, player: Player, touch: TouchControls = null) -> void:
	_world = world
	_player = player
	_touch = touch


func _process(delta: float) -> void:
	_accum += delta
	if _accum < 0.25 or _world == null:
		return
	_accum = 0.0
	var s := _world.get_stats()
	var p := _player.position
	var draw_calls := int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME))
	var tris := int(Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME))
	var mem_mb := Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0
	text = "FPS %d\nXYZ %.1f  %.1f  %.1f\nChunks: data %d  meshed %d  jobs %d\nDraw calls %d   Tris %d\nMem %.1f MB" % [
		Engine.get_frames_per_second(), p.x, p.y, p.z,
		s["data"], s["meshed"], s["jobs"], draw_calls, tris, mem_mb]
	text += "\nFloor %s   Vy %.1f" % ["yes" if _player.on_floor else "no", _player.velocity.y]
	if _touch != null:
		text += "\nStick %.2f %.2f   Jump %s" % [_touch.move_vector.x, _touch.move_vector.y, "down" if _touch.jump_down else "up"]
	if not _world.has_data_at(p):
		text += "\nLoading terrain..."
