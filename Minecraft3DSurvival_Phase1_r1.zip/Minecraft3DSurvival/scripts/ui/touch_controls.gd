class_name TouchControls
extends Control
## Mobile controls: floating joystick (left 45% of screen), look-drag (right side),
## jump button (bottom-right). With "emulate touch from mouse" on, a mouse works in the editor.

const JUMP_RADIUS := 60.0
const SPLIT := 0.45

var move_vector := Vector2.ZERO   # x: right+, y: down+ (so forward = negative y)
var jump_down := false

var _look_accum := Vector2.ZERO
var _move_id := -1
var _look_id := -1
var _jump_id := -1
var _move_origin := Vector2.ZERO
var _move_pos := Vector2.ZERO


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _notification(what: int) -> void:
	# If the app is interrupted (call, control centre, app switch) iOS may never send the
	# touch release, which would leave the player walking or jumping forever.
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		_reset_touches()


func _reset_touches() -> void:
	_move_id = -1
	_look_id = -1
	_jump_id = -1
	move_vector = Vector2.ZERO
	jump_down = false
	_look_accum = Vector2.ZERO
	queue_redraw()


func consume_look() -> Vector2:
	var v := _look_accum
	_look_accum = Vector2.ZERO
	return v


func _screen_size() -> Vector2:
	return get_viewport_rect().size


func _jump_center() -> Vector2:
	var s := _screen_size()
	return Vector2(s.x - 130.0, s.y - 130.0)


func _idle_joystick_center() -> Vector2:
	var s := _screen_size()
	return Vector2(190.0, s.y - 150.0)


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		_on_touch(event)
	elif event is InputEventScreenDrag:
		_on_drag(event)


func _on_touch(e: InputEventScreenTouch) -> void:
	var p := e.position
	var split_x := _screen_size().x * SPLIT
	if e.pressed:
		if _jump_id == -1 and p.distance_to(_jump_center()) <= JUMP_RADIUS * 1.4:
			_jump_id = e.index
			jump_down = true
		elif _move_id == -1 and p.x < split_x:
			_move_id = e.index
			_move_origin = p
			_move_pos = p
			move_vector = Vector2.ZERO
		elif _look_id == -1 and p.x >= split_x:
			_look_id = e.index
	else:
		if e.index == _jump_id:
			_jump_id = -1
			jump_down = false
		elif e.index == _move_id:
			_move_id = -1
			move_vector = Vector2.ZERO
		elif e.index == _look_id:
			_look_id = -1
	queue_redraw()


func _on_drag(e: InputEventScreenDrag) -> void:
	if e.index == _move_id:
		var radius := GameSettings.joystick_radius
		var offset := (e.position - _move_origin).limit_length(radius)
		move_vector = offset / radius
		_move_pos = _move_origin + offset
		queue_redraw()
	elif e.index == _look_id:
		_look_accum += e.relative


func _draw() -> void:
	var radius := GameSettings.joystick_radius
	var base := _move_origin if _move_id != -1 else _idle_joystick_center()
	var knob := _move_pos if _move_id != -1 else base
	draw_circle(base, radius, Color(1, 1, 1, 0.10))
	draw_arc(base, radius, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(knob, 36.0, Color(1, 1, 1, 0.35))

	var jc := _jump_center()
	var alpha := 0.40 if jump_down else 0.18
	draw_circle(jc, JUMP_RADIUS, Color(1, 1, 1, alpha))
	draw_arc(jc, JUMP_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.45), 3.0)
	draw_string(ThemeDB.fallback_font, jc + Vector2(-60, 8), "JUMP",
		HORIZONTAL_ALIGNMENT_CENTER, 120.0, 22, Color(1, 1, 1, 0.8))
