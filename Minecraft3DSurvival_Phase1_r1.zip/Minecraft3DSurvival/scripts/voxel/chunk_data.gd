class_name ChunkData
extends RefCounted
## Raw block storage for one chunk column: 16 x 64 x 16 bytes (16 KB).
## Index layout: (y * SIZE + z) * SIZE + x

const SIZE := GameConstants.CHUNK_SIZE
const HEIGHT := GameConstants.CHUNK_HEIGHT

var coord: Vector2i
var blocks := PackedByteArray()
var max_y := 0   # highest non-air y; lets the mesher skip empty sky


func _init(chunk_coord: Vector2i = Vector2i.ZERO) -> void:
	coord = chunk_coord
	blocks.resize(SIZE * HEIGHT * SIZE)  # zero-filled = AIR


static func index_of(x: int, y: int, z: int) -> int:
	return (y * SIZE + z) * SIZE + x


func get_block(x: int, y: int, z: int) -> int:
	return blocks[(y * SIZE + z) * SIZE + x]


func set_block(x: int, y: int, z: int, id: int) -> void:
	blocks[(y * SIZE + z) * SIZE + x] = id
	if id != BlockRegistry.AIR and y > max_y:
		max_y = y
