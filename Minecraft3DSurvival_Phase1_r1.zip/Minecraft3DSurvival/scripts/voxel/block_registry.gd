class_name BlockRegistry
extends RefCounted
## Static block definitions. Everything is `const`, so it is safe to read from worker threads.
## To add a block: add an id, then one entry in each table below (same index).

const AIR := 0
const GRASS := 1
const DIRT := 2
const STONE := 3
const SAND := 4
const BEDROCK := 5
const COUNT := 6

const NAMES := ["Air", "Grass", "Dirt", "Stone", "Sand", "Bedrock"]

# Blocks the player collides with.
const SOLID := [false, true, true, true, true, true]

# Blocks that hide the faces of neighbours (all current blocks are fully opaque cubes).
const OPAQUE := [false, true, true, true, true, true]

# Atlas tile per face: [top, bottom, side]
const TILES := [
	[0, 0, 0],  # air (never drawn)
	[BlockAtlas.TILE_GRASS_TOP, BlockAtlas.TILE_DIRT, BlockAtlas.TILE_GRASS_SIDE],
	[BlockAtlas.TILE_DIRT, BlockAtlas.TILE_DIRT, BlockAtlas.TILE_DIRT],
	[BlockAtlas.TILE_STONE, BlockAtlas.TILE_STONE, BlockAtlas.TILE_STONE],
	[BlockAtlas.TILE_SAND, BlockAtlas.TILE_SAND, BlockAtlas.TILE_SAND],
	[BlockAtlas.TILE_BEDROCK, BlockAtlas.TILE_BEDROCK, BlockAtlas.TILE_BEDROCK],
]
