class_name ChunkMesher
extends RefCounted
## Converts a ChunkData into mesh arrays using hidden-face culling.
## Pure function of its inputs (no scene access), so it is safe to run on a worker thread.
## Neighbour order for `nbrs`: [+X, -X, +Z, -Z] (each a ChunkData).

const S := GameConstants.CHUNK_SIZE
const H := GameConstants.CHUNK_HEIGHT

# Face order: 0 top(+Y), 1 bottom(-Y), 2 +X, 3 -X, 4 +Z, 5 -Z
const FACE_NORMALS := [
	Vector3i(0, 1, 0), Vector3i(0, -1, 0),
	Vector3i(1, 0, 0), Vector3i(-1, 0, 0),
	Vector3i(0, 0, 1), Vector3i(0, 0, -1),
]

# Corner order is clockwise when seen from outside (Godot's front-face winding).
const FACE_VERTS := [
	[Vector3(0, 1, 0), Vector3(1, 1, 0), Vector3(1, 1, 1), Vector3(0, 1, 1)],  # top
	[Vector3(0, 0, 0), Vector3(0, 0, 1), Vector3(1, 0, 1), Vector3(1, 0, 0)],  # bottom
	[Vector3(1, 0, 1), Vector3(1, 1, 1), Vector3(1, 1, 0), Vector3(1, 0, 0)],  # +X
	[Vector3(0, 0, 0), Vector3(0, 1, 0), Vector3(0, 1, 1), Vector3(0, 0, 1)],  # -X
	[Vector3(0, 0, 1), Vector3(0, 1, 1), Vector3(1, 1, 1), Vector3(1, 0, 1)],  # +Z
	[Vector3(1, 0, 0), Vector3(1, 1, 0), Vector3(0, 1, 0), Vector3(0, 0, 0)],  # -Z
]

# Tile-local UVs per corner (v axis points down, so tile tops are at v = 0).
const FACE_UVS := [
	[Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)],
	[Vector2(0, 0), Vector2(0, 1), Vector2(1, 1), Vector2(1, 0)],
	[Vector2(0, 1), Vector2(0, 0), Vector2(1, 0), Vector2(1, 1)],
	[Vector2(0, 1), Vector2(0, 0), Vector2(1, 0), Vector2(1, 1)],
	[Vector2(0, 1), Vector2(0, 0), Vector2(1, 0), Vector2(1, 1)],
	[Vector2(0, 1), Vector2(0, 0), Vector2(1, 0), Vector2(1, 1)],
]

# Baked directional brightness (cheap stand-in for lighting; real light levels come later).
const FACE_SHADE := [1.0, 0.5, 0.6, 0.6, 0.8, 0.8]


## Returns an Array suitable for ArrayMesh.add_surface_from_arrays(), or [] if nothing is visible.
static func build(data: ChunkData, nbrs: Array) -> Array:
	var blocks: PackedByteArray = data.blocks
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var cols := PackedColorArray()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	var vcount := 0
	var top_y := mini(data.max_y + 1, H)

	for y in range(top_y):
		for z in range(S):
			for x in range(S):
				var id: int = blocks[(y * S + z) * S + x]
				if id == BlockRegistry.AIR:
					continue
				var tiles: Array = BlockRegistry.TILES[id]
				for f in range(6):
					var n: Vector3i = FACE_NORMALS[f]
					if _opaque_at(blocks, nbrs, x + n.x, y + n.y, z + n.z):
						continue
					var tile: int = tiles[0] if f == 0 else (tiles[1] if f == 1 else tiles[2])
					var rect := BlockAtlas.tile_rect(tile)
					var shade: float = FACE_SHADE[f]
					var color := Color(shade, shade, shade)
					var normal := Vector3(n)
					var fv: Array = FACE_VERTS[f]
					var fu: Array = FACE_UVS[f]
					for k in range(4):
						var v: Vector3 = fv[k]
						verts.append(Vector3(x + v.x, y + v.y, z + v.z))
						norms.append(normal)
						cols.append(color)
						var l: Vector2 = fu[k]
						uvs.append(Vector2(
							rect.position.x + lerpf(BlockAtlas.UV_INSET, 1.0 - BlockAtlas.UV_INSET, l.x) * rect.size.x,
							rect.position.y + lerpf(BlockAtlas.UV_INSET, 1.0 - BlockAtlas.UV_INSET, l.y) * rect.size.y))
					idx.append(vcount)
					idx.append(vcount + 1)
					idx.append(vcount + 2)
					idx.append(vcount)
					idx.append(vcount + 2)
					idx.append(vcount + 3)
					vcount += 4

	if verts.is_empty():
		return []
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = idx
	return arrays


static func _opaque_at(blocks: PackedByteArray, nbrs: Array, x: int, y: int, z: int) -> bool:
	if y < 0:
		return true    # nothing is drawn under the world
	if y >= H:
		return false
	if x >= 0 and x < S and z >= 0 and z < S:
		return BlockRegistry.OPAQUE[blocks[(y * S + z) * S + x]]
	var other: ChunkData
	var lx := x
	var lz := z
	if x >= S:
		other = nbrs[0]
		lx = x - S
	elif x < 0:
		other = nbrs[1]
		lx = x + S
	elif z >= S:
		other = nbrs[2]
		lz = z - S
	else:
		other = nbrs[3]
		lz = z + S
	if other == null:
		return true
	return BlockRegistry.OPAQUE[other.blocks[(y * S + lz) * S + lx]]
