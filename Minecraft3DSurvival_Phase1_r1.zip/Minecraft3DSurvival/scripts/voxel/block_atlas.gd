class_name BlockAtlas
extends RefCounted
## Procedurally generated texture atlas (original art, no external files).
## Layout: COLS x ROWS tiles of TILE_PX pixels each.

const TILE_PX := 16
const COLS := 4
const ROWS := 2
const UV_INSET := 0.02   # fraction of a tile trimmed from each edge to stop bleeding

const TILE_GRASS_TOP := 0
const TILE_GRASS_SIDE := 1
const TILE_DIRT := 2
const TILE_STONE := 3
const TILE_SAND := 4
const TILE_BEDROCK := 5
const TILE_COUNT := 6


static func tile_rect(tile: int) -> Rect2:
	var col := tile % COLS
	@warning_ignore("integer_division")
	var row := tile / COLS
	return Rect2(
		Vector2(float(col) / COLS, float(row) / ROWS),
		Vector2(1.0 / COLS, 1.0 / ROWS)
	)


static func create_material() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED  # shading is baked into vertex colours
	m.albedo_texture = create_texture()
	m.vertex_color_use_as_albedo = true
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.cull_mode = BaseMaterial3D.CULL_BACK
	return m


static func create_texture() -> ImageTexture:
	var img := Image.create_empty(TILE_PX * COLS, TILE_PX * ROWS, false, Image.FORMAT_RGBA8)
	for tile in range(TILE_COUNT):
		_paint_tile(img, tile)
	return ImageTexture.create_from_image(img)


static func _paint_tile(img: Image, tile: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 7919 * (tile + 1)
	var ox := (tile % COLS) * TILE_PX
	@warning_ignore("integer_division")
	var oy := (tile / COLS) * TILE_PX
	for py in range(TILE_PX):
		for px in range(TILE_PX):
			var base := _tile_color(tile, px, py)
			var v := rng.randf_range(0.88, 1.08)
			img.set_pixel(ox + px, oy + py, Color(
				clampf(base.r * v, 0.0, 1.0),
				clampf(base.g * v, 0.0, 1.0),
				clampf(base.b * v, 0.0, 1.0),
				1.0))


static func _tile_color(tile: int, px: int, py: int) -> Color:
	var grass := Color(0.36, 0.62, 0.22)
	var dirt := Color(0.52, 0.37, 0.24)
	match tile:
		TILE_GRASS_TOP:
			return grass
		TILE_GRASS_SIDE:
			if py < 4 + ((px * 5) % 3):
				return grass
			return dirt
		TILE_DIRT:
			return dirt
		TILE_STONE:
			return Color(0.50, 0.50, 0.52)
		TILE_SAND:
			return Color(0.86, 0.80, 0.55)
		TILE_BEDROCK:
			return Color(0.20, 0.20, 0.22)
	return Color(1.0, 0.0, 1.0)  # missing tile = magenta
