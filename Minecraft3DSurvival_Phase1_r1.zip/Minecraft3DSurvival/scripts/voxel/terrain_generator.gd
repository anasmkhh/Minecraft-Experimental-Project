class_name TerrainGenerator
extends RefCounted
## Deterministic procedural terrain: same seed + coord always gives the same chunk.
## Static and self-contained (creates its own noise per call), so it is thread-safe.

const S := GameConstants.CHUNK_SIZE
const H := GameConstants.CHUNK_HEIGHT

const BASE_HEIGHT := 28
const AMPLITUDE := 16.0
const SAND_LEVEL := 23   # columns at or below this are sandy (future water line)


static func _make_noise(world_seed: int) -> FastNoiseLite:
	var n := FastNoiseLite.new()
	n.seed = world_seed
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.frequency = 0.012
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = 4
	return n


static func _height(noise: FastNoiseLite, wx: int, wz: int) -> int:
	var h := BASE_HEIGHT + int(noise.get_noise_2d(wx, wz) * AMPLITUDE)
	return clampi(h, 2, H - 2)


## Height of the top solid block at a world column.
static func surface_height(world_seed: int, wx: int, wz: int) -> int:
	return _height(_make_noise(world_seed), wx, wz)


static func generate_chunk(coord: Vector2i, world_seed: int) -> ChunkData:
	var data := ChunkData.new(coord)
	var noise := _make_noise(world_seed)
	var ox := coord.x * S
	var oz := coord.y * S
	for z in range(S):
		for x in range(S):
			var h := _height(noise, ox + x, oz + z)
			var sandy := h <= SAND_LEVEL
			for y in range(h + 1):
				var id: int
				if y == 0:
					id = BlockRegistry.BEDROCK
				elif y == h:
					id = BlockRegistry.SAND if sandy else BlockRegistry.GRASS
				elif y >= h - 3:
					id = BlockRegistry.SAND if sandy else BlockRegistry.DIRT
				else:
					id = BlockRegistry.STONE
				data.set_block(x, y, z, id)
	return data
