class_name VoxelWorld
extends Node3D
## Owns all chunks. Streams chunks around the focus node (the player).
##
## Pipeline per chunk:  generate data (worker thread)  ->  mesh (worker thread)
##                      ->  create MeshInstance3D (main thread, rate-limited).
## Data is generated one ring beyond the meshed radius so every meshed chunk
## has all four neighbours available for correct border face culling.

const S := GameConstants.CHUNK_SIZE
const H := GameConstants.CHUNK_HEIGHT
const MAX_TASKS_IN_FLIGHT := 3
const MAX_MESH_APPLY_PER_FRAME := 2

var world_seed := 0
var render_distance := 3

var _focus: Node3D
var _material: StandardMaterial3D
var _data: Dictionary = {}         # Vector2i -> ChunkData
var _nodes: Dictionary = {}        # Vector2i -> MeshInstance3D (or null for an empty mesh)
var _gen_tasks: Dictionary = {}    # Vector2i -> WorkerThreadPool task id
var _mesh_tasks: Dictionary = {}   # Vector2i -> WorkerThreadPool task id
var _mutex := Mutex.new()
var _results: Array = []           # written by workers, guarded by _mutex
var _inbox: Array = []             # main thread only
var _offsets: Array[Vector2i] = []
var _center := Vector2i(1 << 30, 1 << 30)
var _dirty := true
var _active := false


func setup(seed_value: int, focus: Node3D) -> void:
	world_seed = seed_value
	_focus = focus
	render_distance = GameSettings.render_distance
	_material = BlockAtlas.create_material()
	_build_offsets()
	_active = true


# ---------------------------------------------------------------- public API

## True if the block at integer world coordinates blocks movement.
## Unloaded chunks count as solid so nothing can fall into the unknown.
func is_solid(x: int, y: int, z: int) -> bool:
	if y < 0:
		return true
	if y >= H:
		return false
	var chunk: ChunkData = _data.get(Vector2i(_floor_div(x), _floor_div(z)))
	if chunk == null:
		return true
	return BlockRegistry.SOLID[chunk.get_block(posmod(x, S), y, posmod(z, S))]


func get_block(x: int, y: int, z: int) -> int:
	if y < 0 or y >= H:
		return BlockRegistry.AIR
	var chunk: ChunkData = _data.get(Vector2i(_floor_div(x), _floor_div(z)))
	if chunk == null:
		return BlockRegistry.AIR
	return chunk.get_block(posmod(x, S), y, posmod(z, S))


func has_data_at(p: Vector3) -> bool:
	return _data.has(Vector2i(_floor_div(floori(p.x)), _floor_div(floori(p.z))))


func get_stats() -> Dictionary:
	return {
		"data": _data.size(),
		"meshed": _nodes.size(),
		"jobs": _gen_tasks.size() + _mesh_tasks.size(),
	}


# ---------------------------------------------------------------- main loop

func _process(_delta: float) -> void:
	if not _active:
		return
	var c := _chunk_of(_focus.position)
	if c != _center:
		_center = c
		_unload_far()
		_dirty = true
	_collect_results()
	_apply_results()
	if _dirty:
		_schedule_jobs()


func _exit_tree() -> void:
	for t in _gen_tasks.values():
		WorkerThreadPool.wait_for_task_completion(t)
	for t in _mesh_tasks.values():
		WorkerThreadPool.wait_for_task_completion(t)


# ---------------------------------------------------------------- scheduling

func _build_offsets() -> void:
	_offsets.clear()
	var r := render_distance + 1
	for dz in range(-r, r + 1):
		for dx in range(-r, r + 1):
			_offsets.append(Vector2i(dx, dz))
	_offsets.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return (a.x * a.x + a.y * a.y) < (b.x * b.x + b.y * b.y))


func _schedule_jobs() -> void:
	for o in _offsets:
		if _gen_tasks.size() + _mesh_tasks.size() >= MAX_TASKS_IN_FLIGHT:
			return  # stay dirty; try again next frame
		var coord := _center + o
		if not _data.has(coord):
			if not _gen_tasks.has(coord):
				_gen_tasks[coord] = WorkerThreadPool.add_task(
					_gen_job.bind(coord), false, "gen_chunk")
			continue
		if absi(o.x) > render_distance or absi(o.y) > render_distance:
			continue
		if _nodes.has(coord) or _mesh_tasks.has(coord):
			continue
		var nbrs := _get_neighbors(coord)
		if nbrs.is_empty():
			continue
		_mesh_tasks[coord] = WorkerThreadPool.add_task(
			_mesh_job.bind(coord, _data[coord], nbrs), false, "mesh_chunk")
	_dirty = false


func _get_neighbors(coord: Vector2i) -> Array:
	var res: Array = []
	for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		var n = _data.get(coord + d)
		if n == null:
			return []
		res.append(n)
	return res


# ---------------------------------------------------------------- worker jobs

func _gen_job(coord: Vector2i) -> void:
	var d := TerrainGenerator.generate_chunk(coord, world_seed)
	_push_result({"kind": "data", "coord": coord, "data": d})


func _mesh_job(coord: Vector2i, data: ChunkData, nbrs: Array) -> void:
	var arrays := ChunkMesher.build(data, nbrs)
	_push_result({"kind": "mesh", "coord": coord, "arrays": arrays})


func _push_result(r: Dictionary) -> void:
	_mutex.lock()
	_results.append(r)
	_mutex.unlock()


# ---------------------------------------------------------------- results

func _collect_results() -> void:
	_mutex.lock()
	if not _results.is_empty():
		_inbox.append_array(_results)
		_results.clear()
	_mutex.unlock()


func _apply_results() -> void:
	var meshes_applied := 0
	while not _inbox.is_empty():
		var r: Dictionary = _inbox.pop_front()
		var coord: Vector2i = r["coord"]
		if r["kind"] == "data":
			_finish_task(_gen_tasks, coord)
			if _within(coord, render_distance + 2):
				_data[coord] = r["data"]
			_dirty = true
		else:
			if meshes_applied >= MAX_MESH_APPLY_PER_FRAME:
				_inbox.push_front(r)
				return
			_finish_task(_mesh_tasks, coord)
			if _within(coord, render_distance + 1):
				_create_chunk_node(coord, r["arrays"])
				meshes_applied += 1
			_dirty = true


func _finish_task(tasks: Dictionary, coord: Vector2i) -> void:
	if tasks.has(coord):
		WorkerThreadPool.wait_for_task_completion(tasks[coord])
		tasks.erase(coord)


func _create_chunk_node(coord: Vector2i, arrays: Array) -> void:
	_remove_chunk_node(coord)
	if arrays.is_empty():
		_nodes[coord] = null
		return
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var mi := MeshInstance3D.new()
	mi.name = "Chunk_%d_%d" % [coord.x, coord.y]
	mi.mesh = mesh
	mi.material_override = _material
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = Vector3(coord.x * S, 0, coord.y * S)
	add_child(mi)
	_nodes[coord] = mi
	EventBus.chunk_meshed.emit(coord)


func _remove_chunk_node(coord: Vector2i) -> void:
	if _nodes.has(coord):
		var old = _nodes[coord]
		if old != null and is_instance_valid(old):
			old.queue_free()
		_nodes.erase(coord)


func _unload_far() -> void:
	for coord in _data.keys():
		if not _within(coord, render_distance + 2):
			_data.erase(coord)
	for coord in _nodes.keys():
		if not _within(coord, render_distance + 1):
			_remove_chunk_node(coord)


# ---------------------------------------------------------------- helpers

func _within(coord: Vector2i, radius: int) -> bool:
	var d := coord - _center
	return maxi(absi(d.x), absi(d.y)) <= radius


func _chunk_of(p: Vector3) -> Vector2i:
	return Vector2i(_floor_div(floori(p.x)), _floor_div(floori(p.z)))


func _floor_div(v: int) -> int:
	return floori(float(v) / S)
