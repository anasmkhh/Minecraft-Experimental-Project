extends Node3D
## Entry point. Builds the world, player and UI in code (keeps the .tscn tiny and robust).

var _world: VoxelWorld
var _player: Player
var _touch: TouchControls
var _hud: DebugHUD


func _ready() -> void:
	_setup_environment()

	var world_seed := GameSettings.world_seed
	_world = VoxelWorld.new()
	_world.name = "VoxelWorld"
	add_child(_world)

	_player = Player.new()
	_player.name = "Player"
	add_child(_player)

	var ui := CanvasLayer.new()
	ui.name = "UI"
	add_child(ui)
	_touch = TouchControls.new()
	_touch.name = "TouchControls"
	ui.add_child(_touch)
	_hud = DebugHUD.new()
	_hud.name = "DebugHUD"
	ui.add_child(_hud)

	var spawn_h := TerrainGenerator.surface_height(world_seed, 0, 0)
	_player.setup(_world, _touch, Vector3(0.5, spawn_h + 2.0, 0.5))
	_world.setup(world_seed, _player)
	_hud.setup(_world, _player, _touch)


func _setup_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.53, 0.75, 0.95)
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
