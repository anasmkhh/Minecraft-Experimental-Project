extends Node
## Global signal hub. Systems talk through signals instead of hard references.
## Autoload name: EventBus

@warning_ignore("unused_signal")
signal chunk_meshed(coord: Vector2i)

@warning_ignore("unused_signal")
signal player_spawned(position: Vector3)
