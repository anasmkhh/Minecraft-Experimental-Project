extends Node
## Global tunable settings + runtime input-action registration.
## Autoload name: GameSettings

var world_seed: int = 20261114
var render_distance: int = 3          # chunks; 3 = 7x7 meshed area (mobile-safe default)
var look_sensitivity: float = 0.0045  # radians per pixel of drag
var fov: float = 75.0
var joystick_radius: float = 90.0     # pixels


func _ready() -> void:
	_register_input_actions()


func _register_input_actions() -> void:
	_add_key_action(&"move_forward", [KEY_W, KEY_UP])
	_add_key_action(&"move_back", [KEY_S, KEY_DOWN])
	_add_key_action(&"move_left", [KEY_A, KEY_LEFT])
	_add_key_action(&"move_right", [KEY_D, KEY_RIGHT])
	_add_key_action(&"jump", [KEY_SPACE])


func _add_key_action(action: StringName, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action, ev)
